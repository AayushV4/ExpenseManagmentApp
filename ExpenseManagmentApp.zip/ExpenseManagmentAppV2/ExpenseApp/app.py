from website import create_app
import os


app = create_app()


if __name__ == '__app__':
    app.run(debug=True)